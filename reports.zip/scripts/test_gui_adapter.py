"""Deterministic Phase 3A GUI adapter checks; no CORE or campaign is started."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

from gui import adapter
from testbed import run_store


class FakeTopology:
    def canonical_snapshot(self) -> dict:
        return {"topology_version": "test-topology", "case_name": "case14", "nodes": [{"id": "hub", "hostname": "s1", "node_type": "hub"}, {"id": "plc1", "hostname": "plc1", "node_type": "plc"}], "links": [{"from": "hub", "to": "plc1", "type": "comm", "protocol": "TCP/IP"}]}


def main() -> None:
    original_data, original_runs = adapter.DATA, run_store.RUNS
    original_request, original_topology = adapter.core_request, adapter.canonical_topology
    try:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); adapter.DATA = root / "data"; run_store.RUNS = adapter.DATA / "runs"; adapter.canonical_topology = lambda: FakeTopology(); adapter._active_cache.clear()
            def offline(_: str) -> dict: raise RuntimeError("CORE daemon unavailable")
            adapter.core_request = offline
            status = adapter.get_system_status()
            assert status["core"]["state"] == "OFFLINE" and status["watcher"]["state"] == "STOPPED"
            assert adapter.get_active_run() is None
            (adapter.DATA / "core-runtime").mkdir(parents=True)
            (adapter.DATA / "core-runtime" / "session.json").write_text("{broken", encoding="utf-8")
            assert adapter.get_system_status()["runtime_marker"] is False
            generation = "c6f2c4a9cb8f4c41aba19789dcadf6c3"
            (adapter.DATA / "core-runtime" / "session.json").write_text(json.dumps({"id": 3, "generation_id": generation}), encoding="utf-8")
            adapter.core_request = lambda _: {"state": "RUNTIME", "session_id": 3, "watcher": "IDLE"}
            topology = FakeTopology().canonical_snapshot(); run = run_store.create_run(topology, scenario_id="scenario-guiadapter")
            run_store.update_run(run["scenario_id"], run["run_id"], core_session_id=3, generation_id=generation, lifecycle_status="RUNNING")
            active = adapter.get_active_run()
            assert active and active["state"] == "ACTIVE" and active["integrity_validated"] is False
            assert adapter.get_displayable_active_run()["integrity_validated"] is True
            (Path(run["path"]) / "events.jsonl").write_text("{broken\n", encoding="utf-8")
            adapter._active_cache.clear()
            assert adapter.get_displayable_active_run()["state"] == "REJECTED"
            (Path(run["path"]) / "events.jsonl").unlink()
            adapter._active_cache.clear()
            assert adapter.get_recent_network_events(run["scenario_id"], run["run_id"], 100) == []
            assert adapter.get_recent_security_events(run["scenario_id"], run["run_id"], 100) == []
            configuration = adapter.get_network_configuration(); assert configuration["node_count"] == 2 and configuration["edge_count"] == 1
            assert {node["state"] for node in adapter.get_topology()["visual"]["nodes"]} == {"normal"}
            for number in range(140): run_store.append_event(run["scenario_id"], run["run_id"], category="network", event_type="packet", source_node="attacker", target_node="plc1", sequence=number)
            for number in range(120): run_store.append_event(run["scenario_id"], run["run_id"], category="security", event_type="attack_started", target_node="plc1", correlation_id=f"corr-{number}", sequence=number)
            run_store.append_event(run["scenario_id"], run["run_id"], category="security", event_type="attack_finished", target_node="plc1", correlation_id="corr-report", mitre_technique="T0836", result="detected", evidence={"step_name": "write register", "ml_confidence": 0.91, "detection_method": "hybrid"})
            run_store.append_event(run["scenario_id"], run["run_id"], category="security", event_type="detection", target_node="plc1", correlation_id="corr-report", result="detected", severity="HIGH", detection_method="hybrid")
            network = adapter.get_recent_network_events(run["scenario_id"], run["run_id"], 100); security = adapter.get_recent_security_events(run["scenario_id"], run["run_id"], 100)
            assert len(network) == 100 and len(security) == 100
            assert {event["category"] for event in network} == {"network"} and {event["category"] for event in security} == {"security"}
            assert network[-1]["sequence"] == 139 and any(event.get("sequence") == 119 for event in security)
            assert "source_port" not in network[0] and "mitre_technique" not in security[0]
            try: adapter.get_recent_network_events(run["scenario_id"], run["run_id"], 501)
            except ValueError: pass
            else: raise AssertionError("event limit must be bounded")
            snapshot = adapter.get_live_battle_snapshot(100)
            assert len(snapshot["network_events"]) == 100 and len(snapshot["security_events"]) == 100
            assert {node["state"] for node in snapshot["visual"]["nodes"]} >= {"detected"}
            summary = adapter.get_report_summary()
            assert summary["available"] is False and summary["normalized_records"] == 1
            (Path(run["path"]) / "report.html").write_text("existing report", encoding="utf-8")
            assert adapter.get_report_summary()["available"] is True
            network_path = Path(run["path"]) / "network_events.jsonl"
            network_path.write_bytes(network_path.read_bytes() + b"{partial")
            try: adapter.get_recent_network_events(run["scenario_id"], run["run_id"], 100)
            except ValueError: pass
            else: raise AssertionError("partial canonical event data must be rejected")
    finally:
        adapter.DATA, run_store.RUNS = original_data, original_runs
        adapter.core_request, adapter.canonical_topology = original_request, original_topology; adapter._active_cache.clear()
    print("GUI Phase 3A adapter regression: PASS")


if __name__ == "__main__": main()
