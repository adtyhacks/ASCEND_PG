"""Thin, read-oriented adapter for ASCEND-PG's dedicated GUI."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from testbed import run_store
from testbed.core_runtime import core_request
from testbed.topology import get_topology as canonical_topology


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
MAX_EVENT_LIMIT = 500
_active_cache: dict[tuple[str, str], tuple[dict[str, Any] | None, str | None]] = {}


def _read_json(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return value if isinstance(value, dict) else None


def _runtime_marker() -> dict[str, Any] | None:
    return _read_json(DATA / "core-runtime" / "session.json")


def get_system_status() -> dict[str, Any]:
    """Read CORE status through its existing read-only helper."""
    runtime = _runtime_marker()
    try:
        core = core_request("status")
        core_state = core.get("state", "UNKNOWN")
        watcher_state = core.get("watcher", "UNKNOWN")
        daemon = "AVAILABLE"
    except RuntimeError as exc:
        core, core_state, watcher_state, daemon = {"error": str(exc)}, "OFFLINE", "STOPPED", "UNAVAILABLE"
    return {
        "core": {"state": core_state, "daemon": daemon, "session_id": core.get("session_id")},
        "watcher": {"state": watcher_state},
        "generation": runtime.get("generation_id") if runtime else None,
        "runtime_marker": bool(runtime),
    }


def get_active_run(*, verify_integrity: bool = False) -> dict[str, Any] | None:
    """Recover the current owned run without scanning its event history by default.

    ``recover_displayable_active_run`` remains available for the explicit
    integrity path.  It intentionally reads the aggregate event stream, so it
    must not become an incidental cost of loading every GUI page.
    """
    runtime = _runtime_marker()
    if not runtime:
        return None
    run = run_store.recover_active_run(runtime)
    if not run:
        return None
    if verify_integrity:
        key = (str(runtime.get("generation_id")), run["run_id"])
        if key not in _active_cache:
            displayable, integrity_error = run_store.recover_displayable_active_run(runtime)
            _active_cache[key] = (displayable, str(integrity_error) if integrity_error else None)
        displayable, integrity_error = _active_cache[key]
        if not displayable:
            return {"state": "REJECTED", "run_id": run["run_id"], "scenario_id": run["scenario_id"],
                    "integrity_error": integrity_error}
        run = displayable
    metrics = _read_json(Path(run["path"]) / "metrics.json")
    return {"state": "ACTIVE", "run": run, "metrics": metrics,
            "integrity_validated": verify_integrity}


def get_displayable_active_run() -> dict[str, Any] | None:
    """Explicit, cached canonical event-store validation for diagnostics."""
    return get_active_run(verify_integrity=True)


def get_topology() -> dict[str, Any]:
    """Load the canonical topology and normal visual state without event replay."""
    topology = canonical_topology().canonical_snapshot()
    nodes, edges, *_ = run_store.visual_data(topology, [])
    return {"topology": topology, "visual": {"nodes": nodes, "edges": edges}}


def get_network_configuration() -> dict[str, Any]:
    topology = canonical_topology().canonical_snapshot()
    types: dict[str, int] = {}
    for node in topology["nodes"]:
        node_type = node.get("node_type", "unknown")
        types[node_type] = types.get(node_type, 0) + 1
    return {"topology_version": topology.get("topology_version"), "case_name": topology.get("case_name"),
            "node_count": len(topology["nodes"]), "edge_count": len(topology["links"]), "node_types": types}


def _recent_jsonl(path: Path, limit: int) -> list[dict[str, Any]]:
    """Bounded tail reader for one canonical JSONL category file."""
    if not isinstance(limit, int) or limit < 1 or limit > MAX_EVENT_LIMIT:
        raise ValueError(f"limit must be between 1 and {MAX_EVENT_LIMIT}")
    if not path.exists():
        return []
    block_size = 64 * 1024
    with path.open("rb") as source:
        position = source.seek(0, 2)
        payload = b""
        while position > 0 and payload.count(b"\n") <= limit:
            size = min(block_size, position)
            position -= size
            source.seek(position)
            payload = source.read(size) + payload
    lines = payload.splitlines()
    if position > 0 and lines:
        lines = lines[1:]
    records: list[dict[str, Any]] = []
    for line in lines[-limit:]:
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Malformed canonical event data in {path.name}: {exc}") from exc
        if isinstance(record, dict):
            records.append(record)
    return records


def get_recent_network_events(scenario_id: str, run_id: str, limit: int = 100) -> list[dict[str, Any]]:
    root = run_store._path(scenario_id, run_id)
    return _recent_jsonl(root / "network_events.jsonl", limit)


def get_recent_security_events(scenario_id: str, run_id: str, limit: int = 100) -> list[dict[str, Any]]:
    root = run_store._path(scenario_id, run_id)
    return _recent_jsonl(root / "security_events.jsonl", limit)


def get_runtime_diagnostics() -> dict[str, Any]:
    status = get_system_status()
    return {**status, "active_run": get_active_run()}


def get_report_summary() -> dict[str, Any]:
    """Return existing report and bounded normalized-record metadata only."""
    active = get_active_run()
    if not active or active.get("state") != "ACTIVE":
        return {"available": False, "reason": "No active owned run", "normalized_records": 0}
    run = active["run"]
    report = Path(run["path"]) / "report.html"
    # report_events is the existing normalization boundary.  Bound its input
    # here so visiting Reports never loads an unbounded security history.
    normalized = run_store.report_events(
        get_recent_security_events(run["scenario_id"], run["run_id"], 100)
    )
    return {"available": report.is_file(), "path": str(report) if report.is_file() else None,
            "run_id": run["run_id"], "scenario_id": run["scenario_id"],
            "normalized_records": len(normalized), "normalized_events": normalized}


def get_live_battle_snapshot(limit: int = 100) -> dict[str, Any]:
    """Read independent bounded canonical evidence streams for Live Battle."""
    active = get_active_run()
    if not active or active.get("state") != "ACTIVE":
        topology = get_topology()
        return {"active_run": active, "network_events": [], "security_events": [],
                "network_event_count": 0, "security_event_count": 0, "campaign": None,
                "topology": topology["topology"], "visual": topology["visual"], "limit": limit}
    run = active["run"]
    network_events = get_recent_network_events(run["scenario_id"], run["run_id"], limit)
    security_events = get_recent_security_events(run["scenario_id"], run["run_id"], limit)
    topology = canonical_topology().canonical_snapshot()
    nodes, edges, *_ = run_store.visual_data(topology, security_events)
    return {"active_run": active, "limit": limit, "network_events": network_events,
            "security_events": security_events, "network_event_count": len(network_events),
            "security_event_count": len(security_events), "campaign": run.get("campaign_request"),
            "topology": topology, "visual": {"nodes": nodes, "edges": edges}}
