import json
from pathlib import Path
path = Path('data/modbus_log.json')
raw = path.read_bytes()
text = raw.decode('utf-8')
original, end = json.JSONDecoder().raw_decode(text)
assert isinstance(original, list)
suffix = text[end:]
events = [json.loads(line) for line in suffix.splitlines() if line.strip()]
assert events and all(e.get('stage') == 'normal_traffic' and e.get('timestamp', '') >= '2026-09-27T17:57' for e in events)
first = end + len(suffix) - len(suffix.lstrip())
Path('data/core-runtime/scada-test-original-combined.log').write_bytes(raw)
path.write_bytes(text[:first].encode('utf-8'))
print('Restored original packet log; retained test poll events in runtime backup:', len(events))