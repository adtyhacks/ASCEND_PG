import json, subprocess, sys
from pathlib import Path
root = Path(__file__).resolve().parents[2]
tests = ['test_plc_templates.py', 'test_bugcheck.py', 'test_padding.py', 'test_any_topology.py', 'test_30bus.py', 'test_unified_pipeline.py', 'test_report.py', 'verify_all.py', 'verify_import.py']
results = []
for test in tests:
    with (root / 'data/core-runtime' / (test + '.log')).open('w') as log:
        try:
            result = subprocess.run([sys.executable, str(root / 'scripts' / test)], cwd=root, stdout=log, stderr=subprocess.STDOUT, timeout=240)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = 124
    results.append({'test': test, 'returncode': code})
    print(test, code, flush=True)
    (root / 'data/core-runtime/existing-test-results.json').write_text(json.dumps(results, indent=2))
raise SystemExit(any(r['returncode'] for r in results))